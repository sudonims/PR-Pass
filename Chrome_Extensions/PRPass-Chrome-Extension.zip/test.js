// function add(arr,char){

// }

// function wrap(string,num,data) {
//     ans=[];
//     // b=data["sample"][num];
//     b='f'
//     c=""
//     for(let i=0;i<12;i++){
//         c+=b;
//     }
//     ans.push(c);
//     for(let i=0;i<string.length;i+=12){
//         a=string.slice(i,i+12);
//         ans.push(a);
//     }
//     return ans;
// }

// str="qwertyuiopasdfghjklzxcvbnmwertyui sdfghjk";

// a=wrap(str);

// console.log(a);

// console.log('a')

a = new String("foo");
b = new String("foo");
c = "foo";
d = "foo";
console.log(a == d);

console.log("11" + "1");
console.log("11" - "1");
